<?php
/*
Plugin Name: Nova Header Settings
Plugin URI: https://www.wearenova.co.uk/
Description: A component of the Nova Healthcare Framework
Version: 1.0
Author: We Are Nova
Author URI: https://www.wearenova.co.uk/
Text Domain: nova-header-settings
*/

class Nova_Header_Settings {

	public $options;

	public function __construct() {
		$this->options = get_option('nova_header_settings');
		$this->register_settings_and_fields();
	}

	public function add_menu_page() {
		add_options_page('Nova Header Settings', 'Nova Header Settings', 'administrator', __FILE__, array( 'Nova_Header_Settings', 'display_header_settings_page'));
	}

	public function display_header_settings_page() {
		?>

		<div class="wrap">

			<h2>Nova Header Settings</h2>
			<form method="post" action="options.php" enctype="multipart/form-data">
				<?php settings_fields('nova_header_settings'); ?>
				<?php do_settings_sections(__FILE__); ?>

				<p class="submit">
					<input name="submit" type="submit" class="button-primary" value="Save Changes" />
				</p>
			</form>
		</div>

		<?php
	}

	public function register_settings_and_fields() {
		register_setting(
			'nova_header_settings', 
			'nova_header_settings',
			array($this, 'nova_validate_settings')
		); 

		add_settings_section(
			'nova_header_settings_section', 
			'Header Settings', 
			array($this, 'nova_header_settings_section_cb'), 
			__FILE__);

		add_settings_field(
			'nova_header_colour', 
			'Header Background Colour', 
			array($this, 'nova_header_colour_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_menu_colour', 
			'Header Menu Text Colour', 
			array($this, 'nova_header_menu_colour_setting'), 
			__FILE__,
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_menu_hover_colour', 
			'Header Menu Text Hover Colour', 
			array($this, 'nova_header_menu_hover_colour_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_logo', 
			'Header Logo', 
			array($this, 'nova_header_logo_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_logo', 
			'Mobile Header Logo', 
			array($this, 'nova_header_mobile_logo_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_padding', 
			'Header Mobile Padding', 
			array($this, 'nova_header_mobile_padding_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_tablet_padding', 
			'Header Tablet Padding', 
			array($this, 'nova_header_tablet_padding_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_desktop_padding', 
			'Header Desktop Padding', 
			array($this, 'nova_header_desktop_padding_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_menu_background_colour', 
			'Header Mobile Menu Background Colour', 
			array($this, 'nova_header_mobile_menu_background_colour_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_menu_text_colour', 
			'Header Mobile Menu Text Colour', 
			array($this, 'nova_header_mobile_menu_text_colour_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_menu_replacement_logo', 
			'Mobile Menu Replacement Logo', 
			array($this, 'nova_header_mobile_menu_replacement_logo_setting'), 
			__FILE__, 
			'nova_header_settings_section');

		add_settings_field(
			'nova_header_mobile_menu_close_icon', 
			'Mobile Menu Close Icon', 
			array($this, 'nova_header_mobile_menu_close_icon_setting'), 
			__FILE__, 
			'nova_header_settings_section');

	}

	public function nova_header_settings_section_cb() {

	}

	/*
	*
	* INPUTS
	*
	*/

	public function nova_header_colour_setting() {
		echo "<input name='nova_header_settings[nova_header_colour]' placeholder='#303030' type='text' value='{$this->options['nova_header_colour']}' />";
	}

	public function nova_header_menu_colour_setting() {
		echo "<input name='nova_header_settings[nova_header_menu_colour]' placeholder='#ffffff' type='text' value='{$this->options['nova_header_menu_colour']}' />";	
	}

	public function nova_header_menu_hover_colour_setting() {
		echo "<input name='nova_header_settings[nova_header_menu_hover_colour]' placeholder='#000000' type='text' value='{$this->options['nova_header_menu_hover_colour']}' />";	
	}

	// header logo settings
	public function nova_header_logo_setting() {
		echo '<input type="file" name="nova_logo_upload" /><br /><br />';
		if( isset($this->options['nova_logo'])) {
			echo "<img src='{$this->options['nova_logo']}' alt='' />";
		}
	}

	public function nova_header_mobile_logo_setting() {
		echo '<input type="file" name="nova_mobile_logo_upload" /><br /><br />';
		if( isset($this->options['nova_mobile_logo'])) {
			echo "<img src='{$this->options['nova_mobile_logo']}' alt='' />";
		}
	}

	// header padding settings
	public function nova_header_mobile_padding_setting() {
		echo "<input name='nova_header_settings[nova_header_mobile_padding]' placeholder='10px 0 10px 0' type='text' value='{$this->options['nova_header_mobile_padding']}' />";
	}

	public function nova_header_tablet_padding_setting() {
		echo "<input name='nova_header_settings[nova_header_tablet_padding]' placeholder='20px 0 20px 0' type='text' value='{$this->options['nova_header_tablet_padding']}' />";
	}

	public function nova_header_desktop_padding_setting() {
		echo "<input name='nova_header_settings[nova_header_desktop_padding]' placeholder='30px 0 30px 0' type='text' value='{$this->options['nova_header_desktop_padding']}' />";
	}

	// burgermenu options
	public function nova_header_mobile_menu_background_colour_setting() {
		echo "<input name='nova_header_settings[nova_header_mobile_menu_background_colour]' placeholder='#000000' type='text' value='{$this->options['nova_header_mobile_menu_background_colour']}' />";
	}

	public function nova_header_mobile_menu_text_colour_setting() {
		echo "<input name='nova_header_settings[nova_header_mobile_menu_text_colour]' placeholder='#ffffff' type='text' value='{$this->options['nova_header_mobile_menu_text_colour']}' />";
	}

	// header logo settings
	public function nova_header_mobile_menu_replacement_logo_setting() {
		echo '<input type="file" name="nova_replacement_logo_upload" /><br /><br />';
		if( isset($this->options['nova_replacement_logo'])) {
			echo "<img src='{$this->options['nova_replacement_logo']}' alt='' />";
		}
	}

	public function nova_header_mobile_menu_close_icon_setting() {
		echo '<input type="file" name="nova_close_icon_upload" /><br /><br />';
		if( isset($this->options['nova_close_icon_upload'])) {
			echo "<img src='{$this->options['nova_close_icon_upload']}' alt='' />";
		}
	}


	public function nova_validate_settings( $plugin_options ) {
		
		// is file img?
		if( !empty($_FILES['nova_logo_upload']['tmp_name']) ) {
			$override = array('test_form' => false);
			$file = wp_handle_upload($_FILES['nova_logo_upload'], $override);
			$plugin_options['nova_logo'] = $file['url'];
		} else {
			$plugin_options['nova_logo'] = $this->options['nova_logo'];
		}
		if( !empty($_FILES['nova_mobile_logo_upload']['tmp_name']) ) {
			$override = array('test_form' => false);
			$file = wp_handle_upload($_FILES['nova_mobile_logo_upload'], $override);
			$plugin_options['nova_mobile_logo'] = $file['url'];
		} else {
			$plugin_options['nova_mobile_logo'] = $this->options['nova_mobile_logo'];
		}

		if( !empty($_FILES['nova_replacement_logo_upload']['tmp_name']) ) {
			$override = array('test_form' => false);
			$file = wp_handle_upload($_FILES['nova_replacement_logo_upload'], $override);
			$plugin_options['nova_replacement_logo'] = $file['url'];
		} else {
			$plugin_options['nova_replacement_logo'] = $this->options['nova_replacement_logo'];
		}		
		if( !empty($_FILES['nova_close_icon_upload']['tmp_name']) ) {
			$override = array('test_form' => false);
			$file = wp_handle_upload($_FILES['nova_close_icon_upload'], $override);
			$plugin_options['nova_close_icon_upload'] = $file['url'];
		} else {
			$plugin_options['nova_close_icon_upload'] = $this->options['nova_close_icon'];
		}		


		return $plugin_options;

	}


}

add_action('admin_menu', function() {
	Nova_Header_Settings::add_menu_page();
});

add_action('admin_init', function() {
	new Nova_Header_Settings();
});