<?php
 
class Nova_Social_Admin {

	public $options;

	public function __construct() {
		$this->options = get_option('nova_social_settings');
		$this->register_settings_and_fields();
	}

	public function add_menu_page() {
		add_options_page('Nova Social Settings', 'Nova Social Settings', 'administrator', __FILE__, array( 'Nova_Social_Admin', 'display_social_settings_page'));
	}

	public function display_social_settings_page() {
		?>
		<div class="wrap">

			<h2>Nova Social Settings</h2>
			<form method="post" action="options.php" enctype="multipart/form-data">
				<?php settings_fields('nova_social_settings'); ?>
				<?php do_settings_sections(__FILE__); ?>

				<p class="submit">
					<input name="submit" type="submit" class="button-primary" value="Save Changes" />
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Register our settings and fields
	 * 
	 * NEEDS: Would like to include alternative FA icon 
	 *
	 * @package nova-social
	 * @since 1.0.0
	 */
	public function register_settings_and_fields() {

		// define registration
		register_setting(
			'nova_social_settings', 
			'nova_social_settings',
			array($this, 'nova_validate_settings')
		);

		add_settings_section(
			'nova_social_settings_section', 
			'Social Settings', 
			array($this, 'nova_social_settings_section_cb'), 
			__FILE__
		);		

		// Facebook
		add_settings_field(
			'nova_social_facebook_url', 
			'Facebook URL', 
			array($this, 'nova_social_facebook_url_setting'), 
			__FILE__, 
			'nova_social_settings_section');

		// Instagram
		add_settings_field(
			'nova_social_instagram_url', 
			'Instagram URL', 
			array($this, 'nova_social_instagram_url_setting'), 
			__FILE__, 
			'nova_social_settings_section');

		// Twitter
		add_settings_field(
			'nova_social_twitter_url', 
			'Twitter URL', 
			array($this, 'nova_social_twitter_url_setting'), 
			__FILE__, 
			'nova_social_settings_section');

		// LinkedIn
		add_settings_field(
			'nova_social_linkedin_url', 
			'Linkedin URL', 
			array($this, 'nova_social_linkedin_url_setting'), 
			__FILE__, 
			'nova_social_settings_section');

	}

	public function nova_social_settings_section_cb() {

	}

	public function nova_social_facebook_url_setting() {
		echo "<input name='nova_social_settings[nova_social_facebook_url]' placeholder='https://www.facebook.com/' type='text' value='{$this->options['nova_social_facebook_url']}' />";
	}

	public function nova_social_instagram_url_setting() {
		echo "<input name='nova_social_settings[nova_social_instagram_url]' placeholder='https://www.instagram.com/' type='text' value='{$this->options['nova_social_instagram_url']}' />";	
	}

	public function nova_social_twitter_url_setting() {
		echo "<input name='nova_social_settings[nova_social_twitter_url]' placeholder='https://www.twitter.com/' type='text' value='{$this->options['nova_social_twitter_url']}' />";	
	}

	public function nova_social_linkedin_url_setting() {
		echo "<input name='nova_social_settings[nova_social_linkedin_url]' placeholder='https://www.linkedin.com/' type='text' value='{$this->options['nova_social_linkedin_url']}' />";	
	}

}


add_action('admin_menu', function() {
	Nova_Social_Admin::add_menu_page();
});

add_action('admin_init', function() {
	new Nova_Social_Admin();
});