<?php
/*
Plugin Name: Nova Footer Settings
Plugin URI: https://www.wearenova.co.uk/
Description: A component of the Nova Healthcare Framework
Version: 1.0
Author: We Are Nova
Author URI: https://www.wearenova.co.uk/
Text Domain: nova-footer-settings
*/

class Nova_Footer_Settings {

	public $options;

	public function __construct() {
		$this->options = get_option('nova_footer_settings');
		$this->register_settings_and_fields();
	}

	public function add_menu_page() {
		add_options_page('Nova Footer Settings', 'Nova Footer Settings', 'administrator', __FILE__, array( 'Nova_Footer_Settings', 'display_footer_settings_page'));
	}

	public function display_footer_settings_page() {
		?>

		<div class="wrap">

			<h2>Nova Footer Settings</h2>
			<form method="post" action="options.php" enctype="multipart/form-data">
				<?php settings_fields('nova_footer_settings'); ?>
				<?php do_settings_sections(__FILE__); ?>

				<p class="submit">
					<input name="submit" type="submit" class="button-primary" value="Save Changes" />
				</p>
			</form>
		</div>

		<?php
	}


	public function nova_footer_settings_section_cb() {

	}

	public function register_settings_and_fields() {
		register_setting(
			'nova_footer_settings', 
			'nova_footer_settings',
			array($this, 'nova_validate_settings')
		); 

		add_settings_section(
			'nova_footer_settings_section', 
			'Footer Settings', 
			array($this, 'nova_footer_settings_section_cb'), 
			__FILE__);

		// footer background colour
		add_settings_field(
			'nova_footer_background_colour', 
			'Footer Background Colour', 
			array($this, 'nova_footer_background_colour_setting'), 
			__FILE__, 
			'nova_footer_settings_section');


		// footer text colour
		add_settings_field(
			'nova_footer_text_colour', 
			'Footer Text Colour', 
			array($this, 'nova_footer_text_colour_setting'), 
			__FILE__,
			'nova_footer_settings_section');


		// footer logo
		add_settings_field(
			'nova_footer_logo', 
			'Footer Logo', 
			array($this, 'nova_footer_logo_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// footer mobile padding
		add_settings_field(
			'nova_footer_mobile_padding', 
			'Footer Mobile Padding', 
			array($this, 'nova_footer_mobile_padding_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// footer tablet padding
		add_settings_field(
			'nova_footer_tablet_padding', 
			'Footer Tablet Padding', 
			array($this, 'nova_footer_tablet_padding_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// footer desktop padding
		add_settings_field(
			'nova_footer_desktop_padding', 
			'Footer Desktop Padding', 
			array($this, 'nova_footer_desktop_padding_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// cofounded with nova
		add_settings_field(
			'nova_footer_show_cofounded_with_nova', 
			'Show Cofounded with Nova text?', 
			array($this, 'nova_footer_show_cofounded_with_nova_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// t&c?
		add_settings_field(
			'nova_footer_show_terms_and_conditions', 
			'Show Terms and Conditions?', 
			array($this, 'nova_footer_show_terms_and_conditions_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// terms and conditions text
		add_settings_field(
			'nova_footer_terms_and_conditions_text', 
			'Terms and Conditions text', 
			array($this, 'nova_footer_terms_and_conditions_text_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// terms and conditions url
		add_settings_field(
			'nova_footer_terms_and_conditions_url', 
			'Terms and Conditions URL', 
			array($this, 'nova_footer_terms_and_conditions_url_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// show privacy statement?
		add_settings_field(
			'nova_footer_show_privacy_statement', 
			'Show Privacy Statement?', 
			array($this, 'nova_footer_show_privacy_statement_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// privacy statement text
		add_settings_field(
			'nova_footer_privacy_statement_text', 
			'Privacy Statement text', 
			array($this, 'nova_footer_privacy_statement_text_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

		// privacy statement URL
		add_settings_field(
			'nova_footer_privacy_statement_url', 
			'Privacy Statement URL', 
			array($this, 'nova_footer_privacy_statement_url_setting'), 
			__FILE__, 
			'nova_footer_settings_section');

	}


	/*
	*
	* INPUTS
	*
	*/

	public function nova_footer_show_cofounded_with_nova_setting() {
		echo "<input type='checkbox' name='nova_footer_settings[nova_footer_show_cofounded_with_nova]' value='{$this->options['nova_footer_show_cofounded_with_nova']}' />";
	}

	public function nova_footer_show_terms_and_conditions_setting() {
		echo "<input type='checkbox' name='nova_footer_settings[nova_footer_show_terms_and_conditions]' value='1'<?php checked( 1 == $this->options['nova_footer_show_terms_and_conditions'] ); ?> />";
	}

	public function nova_footer_show_privacy_statement_setting() {
		echo "<input type='checkbox' name='nova_footer_settings[nova_footer_show_privacy_statement]' value='1'<?php checked( 1 == $this->options['nova_footer_show_privacy_statement'] ); ?> />";
	}

	public function nova_footer_terms_and_conditions_url_setting() {
		echo "<input name='nova_footer_settings[nova_footer_terms_and_conditions_url]' placeholder='http://www.google.com' type='text' value='{$this->options['nova_footer_terms_and_conditions_url']}' />";
	}


	public function nova_footer_terms_and_conditions_text_setting() {
		echo "<input name='nova_footer_settings[nova_footer_terms_and_conditions_text]' placeholder='Terms & Conditions' type='text' value='{$this->options['nova_footer_terms_and_conditions_text']}' />";
	}

	public function nova_footer_background_colour_setting() {
		echo "<input name='nova_footer_settings[nova_footer_background_colour]' placeholder='#303030' type='text' value='{$this->options['nova_footer_background_colour']}' />";
	}

	public function nova_footer_text_colour_setting() {
		echo "<input name='nova_footer_settings[nova_footer_text_colour]' placeholder='#ffffff' type='text' value='{$this->options['nova_footer_text_colour']}' />";	
	}

	// Header logo settings
	public function nova_footer_logo_setting() {
		echo '<input type="file" name="nova_footer_logo_upload" /><br /><br />';
		if( isset($this->options['nova_footer_logo'])) {
			echo "<img src='{$this->options['nova_footer_logo']}' alt='' />";
		}
	}

	// header padding settings
	public function nova_footer_mobile_padding_setting() {
		echo "<input name='nova_footer_settings[nova_footer_mobile_padding]' placeholder='10px 0 10px 0' type='text' value='{$this->options['nova_footer_mobile_padding']}' />";
	}

	public function nova_footer_tablet_padding_setting() {
		echo "<input name='nova_footer_settings[nova_footer_tablet_padding]' placeholder='20px 0 20px 0' type='text' value='{$this->options['nova_footer_tablet_padding']}' />";
	}

	public function nova_footer_desktop_padding_setting() {
		echo "<input name='nova_footer_settings[nova_footer_desktop_padding]' placeholder='30px 0 30px 0' type='text' value='{$this->options['nova_footer_desktop_padding']}' />";
	}


	public function nova_footer_privacy_statement_text_setting() {
		echo "<input name='nova_footer_settings[nova_footer_privacy_statement_text]' placeholder='Privacy Statement' type='text' value='{$this->options['nova_footer_privacy_statement_text']}' />";
	}

	public function nova_footer_privacy_statement_url_setting() {
		echo "<input name='nova_footer_settings[nova_footer_privacy_statement_url]' placeholder='http://www.google.com' type='text' value='{$this->options['nova_footer_privacy_statement_url']}' />";
	}



	public function nova_validate_settings( $plugin_options ) {
		
		// is file img?
		if( !empty($_FILES['nova_footer_logo_upload']['tmp_name']) ) {
			$override = array('test_form' => false);
			$file = wp_handle_upload($_FILES['nova_footer_logo_upload'], $override);
			$plugin_options['nova_footer_logo'] = $file['url'];
		} else {
			$plugin_options['nova_footer_logo'] = $this->options['nova_footer_logo'];
		}

		return $plugin_options;

	}


}

add_action('admin_menu', function() {
	Nova_Footer_Settings::add_menu_page();
});

add_action('admin_init', function() {
	new Nova_Footer_Settings();
});